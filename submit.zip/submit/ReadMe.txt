In order to run the project, please do the folloing

1. unzip stock-ml-mini-project folder
2. open the project in visual studio code
3. open to stock-ml-mini-project/src/program.ipynb or stock-ml-mini-project/src/start.py
4. Provide the API key and Secret key
5. Run the program.ipynb file or run 'python start.py' from command line. 

